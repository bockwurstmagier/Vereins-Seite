import { createClient } from "./supabase/server";
import { getClubIdentityMap } from "./clubs";
import { isPlayingProfile } from "./player-role";

export type MatchCenterMatch = {
  id: string;
  competition: string;
  matchday: string | null;
  home_team: string;
  away_team: string;
  match_date: string;
  location: string | null;
  home_score: number | null;
  away_score: number | null;
  status: "scheduled" | "live" | "finished";
  current_minute: number;
  clock_phase:
    | "stopped"
    | "first_half"
    | "halftime"
    | "second_half"
    | "paused"
    | "finished"
    | null;
  clock_started_at: string | null;
  clock_base_minute: number | null;
  clock_resume_phase: "first_half" | "second_half" | null;
  report: string | null;
  player_of_match_id: string | null;
  formation: string | null;
  home_logo_url?: string | null;
  away_logo_url?: string | null;
};

export type MatchCenterPlayer = {
  id: string;
  first_name: string;
  last_name: string;
  shirt_number: number | null;
  position: string;
  squad: string;
  image_url: string | null;
};

export type MatchCenterEvent = {
  id: string;
  match_id: string;
  event_type: "goal" | "yellow_card" | "red_card" | "substitution" | "note";
  minute: number;
  player_id: string | null;
  secondary_player_id: string | null;
  description: string | null;
  moment_type: "penalty" | "moment" | null;
  video_url: string | null;
  video_path: string | null;
  is_highlight: boolean;
  created_at: string;
};

export type MatchSquadEntry = {
  id: string;
  match_id: string;
  player_id: string;
  role: "starter" | "bench";
  sort_order: number;
  pitch_x: number | null;
  pitch_y: number | null;
  position_label: string | null;
};

export async function getMatchCenterOverview() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("matches")
    .select(
      "id, competition, matchday, home_team, away_team, match_date, location, home_score, away_score, status, current_minute, clock_phase, clock_started_at, clock_base_minute, clock_resume_phase, report, player_of_match_id, formation",
    )
    .or("home_team.ilike.%Middelich-Resse%,away_team.ilike.%Middelich-Resse%")
    .order("match_date", { ascending: false })
    .limit(60);

  if (error) {
    console.error("Match-Center konnte nicht geladen werden:", error.message);
    return [] as MatchCenterMatch[];
  }

  const matches = (data ?? []) as MatchCenterMatch[];
  const clubMap = await getClubIdentityMap(
    supabase,
    matches.flatMap((match) => [match.home_team, match.away_team]),
  );

  return matches.map((match) => ({
    ...match,
    home_logo_url: clubMap.get(match.home_team)?.logo_url ?? null,
    away_logo_url: clubMap.get(match.away_team)?.logo_url ?? null,
  }));
}

export async function getPublicMatchCenterMatch(id: string) {
  const supabase = await createClient();

  const [matchResult, playersResult, eventsResult, squadResult] =
    await Promise.all([
      supabase
        .from("matches")
        .select(
          "id, competition, matchday, home_team, away_team, match_date, location, home_score, away_score, status, current_minute, clock_phase, clock_started_at, clock_base_minute, clock_resume_phase, report, player_of_match_id, formation",
        )
        .eq("id", id)
        .maybeSingle(),
      supabase
        .from("players")
        .select("id, first_name, last_name, shirt_number, position, squad, image_url")
        .eq("is_active", true),
      supabase
        .from("match_events")
        .select(
          "id, match_id, event_type, minute, player_id, secondary_player_id, description, moment_type, video_url, video_path, is_highlight, created_at",
        )
        .eq("match_id", id)
        .order("minute", { ascending: false })
        .order("created_at", { ascending: false }),
      supabase
        .from("match_squad")
        .select("id, match_id, player_id, role, sort_order, pitch_x, pitch_y, position_label")
        .eq("match_id", id)
        .order("role", { ascending: true })
        .order("sort_order", { ascending: true }),
    ]);

  if (matchResult.error || !matchResult.data) return null;

  const match = matchResult.data as MatchCenterMatch;
  const clubMap = await getClubIdentityMap(supabase, [
    match.home_team,
    match.away_team,
  ]);

  return {
    match: {
      ...match,
      home_logo_url: clubMap.get(match.home_team)?.logo_url ?? null,
      away_logo_url: clubMap.get(match.away_team)?.logo_url ?? null,
    },
    players: ((playersResult.data ?? []) as MatchCenterPlayer[]).filter(isPlayingProfile),
    events: (eventsResult.data ?? []) as MatchCenterEvent[],
    squad: (squadResult.data ?? []) as MatchSquadEntry[],
  };
}

export async function getFeaturedMatchCenterMatch() {
  const matches = await getMatchCenterOverview();

  return (
    matches.find((match) => match.status === "live") ??
    [...matches]
      .filter((match) => match.status === "scheduled")
      .sort(
        (a, b) =>
          new Date(a.match_date).getTime() - new Date(b.match_date).getTime(),
      )[0] ??
    matches.find((match) => match.status === "finished") ??
    null
  );
}
